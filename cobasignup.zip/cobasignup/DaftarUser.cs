namespace cobasignup
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class DaftarUser : DbContext
    {
        public DaftarUser()
            : base("name=DaftarUser")
        {
        }

        public virtual DbSet<UserId> UserIds { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
