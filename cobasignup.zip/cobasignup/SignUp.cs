﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace cobasignup
{
    public partial class SignUp : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["DaftarUser"].ConnectionString;

        public SignUp()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (tbUsername.Text != "" && tbPassword.Text != "")
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("TambahUser", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Username", tbUsername.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Password", tbPassword.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Sign up berhasil");
                    Clear();
                }
            }
            else
            {
                MessageBox.Show("Harus diisi.");
            }
        }

        void Clear()
        {
            tbUsername.Text = tbPassword.Text = "";
        }
    }
}
