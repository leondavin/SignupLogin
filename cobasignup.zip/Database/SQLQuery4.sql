﻿ALTER PROC TambahUser
@Username NVARCHAR(50),
@Password NVARCHAR(50)
AS
	INSERT INTO	tbl_DaftarUser(Username, Password)
	VALUES (@Username, @Password)